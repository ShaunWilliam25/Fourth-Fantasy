﻿using System;

internal class Eventlog
{
    public static int Count { get; internal set; }

    internal static void Add(string playerLockInSkill)
    {
        throw new NotImplementedException();
    }

    internal static void RemoveAt(int v)
    {
        throw new NotImplementedException();
    }
}