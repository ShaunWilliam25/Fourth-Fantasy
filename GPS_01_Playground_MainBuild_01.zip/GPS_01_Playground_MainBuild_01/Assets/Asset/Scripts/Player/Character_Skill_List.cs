﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Character_Skill_List : MonoBehaviour {

    public List<GameObject> skillList;
    public List<GameObject> skillHolder;
}
